repo: SergioG-7/Endless-Pull
branch: main

## Last sync
date: 2026-08-25T08:24:28Z

### Updated in this project
- Grounded UI copy/data in real game systems: resources (Gems/Wood/Iron/Food), tower floor & energy, decree cooldowns (Heal 10s, Focus Fire 8s, Regroup 12s, Retreat instant), rarity 1-5★, hero subclasses (Dragon Lancer, Iron Blade, Sniper, etc.), passives (Pain Tolerance, Evasion, Eagle Eye)
- Built Fortress Base HUD, Hero Roster modal, Tactical Combat HUD, Summon Altar, and Workshop (Expedition/Alchemy) screens as one connected interactive prototype

## Screen map
| Project screen | Repo source files |
| --- | --- |
| Fortress Base HUD / resource bar / sidebar | MasterHUD.cs, EconomyManager.cs, SideMenuUI.cs |
| Hero Roster modal | RosterUI.cs, HeroQuickCardUI.cs, HeroData.cs, HeroSubclass.cs, PassiveSkill.cs |
| Tactical Combat HUD (decrees, telegraph) | MasterActionBar.cs, MasterCommander.cs |
| Summon Altar | GachaManager.cs (referenced, not fully read) |
| Workshop (Expedition/Alchemy) | ResourceExpeditionUI.cs, CraftingUI.cs (referenced, not fully read) |
